import { google } from "googleapis";
import config from "../config.js";
import logger from "../logger.js";

export async function logToSheet(blog, status = "Published", errorMessage = "") {
  logger.info("Google Sheet log started");

  const auth = new google.auth.JWT({
    email: config.google.serviceAccountEmail,
    key: config.google.privateKey.replace(/\\n/g, "\n"),
    scopes: ["https://www.googleapis.com/auth/spreadsheets"]
  });

  const sheets = google.sheets({ version: "v4", auth });

  await sheets.spreadsheets.values.append({
    spreadsheetId: config.google.sheetId,
    range: "Sheet1!A:J",
    valueInputOption: "USER_ENTERED",
    requestBody: {
      values: [
        [
          new Date().toISOString(),
          status,
          blog.title || "",
          blog.slug || "",
          blog.category || "",
          blog.mdPath || "",
          blog.imagePath || "",
          blog.source || "",
          blog.date || "",
          errorMessage
        ]
      ]
    }
  });

  logger.info("Google Sheet log completed");
}