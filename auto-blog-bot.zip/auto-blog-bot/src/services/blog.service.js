import { slugify } from "../utils/slug.js";

const ALLOWED_CATEGORIES = [
  "Finance",
  "Health",
  "Govt Jobs",
  "Technology",
  "Cricket",
  "India"
];

function detectCategory(title) {
  const text = title.toLowerCase();

  if (/job|jobs|recruitment|vacancy|sarkari|govt|government|exam|result|admit card/.test(text)) {
    return "Govt Jobs";
  }

  if (/cricket|ipl|icc|bcci|test match|odi|t20|world cup|virat|rohit|dhoni/.test(text)) {
    return "Cricket";
  }

  if (/stock|market|finance|bank|rbi|tax|money|loan|investment|ipo|mutual fund/.test(text)) {
    return "Finance";
  }

  if (/health|doctor|medical|hospital|fitness|disease|medicine|wellness/.test(text)) {
    return "Health";
  }

  if (/tech|technology|software|ai|app|google|microsoft|nvidia|apple|startup|digital/.test(text)) {
    return "Technology";
  }

  return "India";
}

function cleanTitle(title) {
  return title
    .replace(/ - .+$/, "")
    .replace(/\s+/g, " ")
    .trim();
}

export function createBlogPost(topic, author) {
  const title = cleanTitle(topic.title);
  const slug = slugify(title);
  const date = new Date().toISOString().split("T")[0];
  const category = detectCategory(title);

  const excerpt = `Simple updated overview about ${title}. Key details, context, impact and what readers should know.`;

  const image = `/images/${slug}.svg`;

  const markdown = `---
title: "${title.replace(/"/g, '\\"')}"
date: "${date}"
category: "${category}"
excerpt: "${excerpt.replace(/"/g, '\\"')}"
image: "${image}"
image2: ""
author: "${author}"
---

# ${title}

## Overview

${excerpt}

This article explains the topic in a simple and useful way for readers.

## Why This Topic Matters

This topic is important because it is connected with current public interest and recent updates in ${category}.

## Key Points

- This topic is currently relevant.
- Readers are searching for clear information.
- More updates may come later.
- Always follow trusted sources before making decisions.

## Detailed Explanation

${title} is gaining attention because it reflects a current trend. Readers need simple, direct, and useful information without unnecessary confusion.

This post explains the topic, its possible impact, and what readers should watch next.

## Possible Impact

The impact may appear in public discussion, online searches, industry movement, policy updates, market response, or social media conversations.

## What Readers Should Watch Next

Readers should watch for:

- Official updates
- Reliable reports
- Public reaction
- Expert analysis
- Future developments

## Conclusion

${title} is worth following because it has current attention and possible future impact.

`;

  return {
    title,
    slug,
    date,
    category,
    excerpt,
    image,
    author,
    source: topic.link,
    mdPath: `posts/${slug}.md`,
    imagePath: `public/images/${slug}.svg`,
    markdown
  };
}