import Parser from "rss-parser";
import logger from "../logger.js";

const parser = new Parser();

export async function fetchTopics(feeds) {
  logger.info("Fetching RSS topics started");

  const topics = [];

  for (const feed of feeds) {
    try {
      logger.info(`Fetching RSS feed: ${feed}`);

      const result = await parser.parseURL(feed);

      result.items.forEach((item) => {
        if (item.title && item.link) {
          topics.push({
            title: item.title.trim(),
            link: item.link,
            pubDate: item.pubDate || new Date().toISOString()
          });
        }
      });
    } catch (error) {
      logger.error(`RSS fetch failed: ${feed} | ${error.message}`);
    }
  }

  const uniqueTopics = Array.from(
    new Map(topics.map((topic) => [topic.title, topic])).values()
  );

  logger.info(`RSS topics fetched successfully: ${uniqueTopics.length}`);

  if (!uniqueTopics.length) {
    throw new Error("No RSS topics found");
  }

  return uniqueTopics.sort((a, b) => new Date(b.pubDate) - new Date(a.pubDate));
}