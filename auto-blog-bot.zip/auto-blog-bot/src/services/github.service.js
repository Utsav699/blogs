import axios from "axios";
import config from "../config.js";
import logger from "../logger.js";

async function getExistingFileSha(path) {
  try {
    const url = `https://api.github.com/repos/${config.github.owner}/${config.github.repo}/contents/${path}`;

    const response = await axios.get(url, {
      headers: {
        Authorization: `Bearer ${config.github.token}`,
        Accept: "application/vnd.github+json"
      },
      params: {
        ref: config.github.branch
      }
    });

    return response.data.sha;
  } catch (error) {
    if (error.response?.status === 404) {
      return null;
    }

    throw error;
  }
}

export async function pushFileToGitHub(path, content, message) {
  logger.info(`GitHub push started: ${path}`);

  const sha = await getExistingFileSha(path);

  const url = `https://api.github.com/repos/${config.github.owner}/${config.github.repo}/contents/${path}`;

  const body = {
    message,
    content: Buffer.from(content, "utf8").toString("base64"),
    branch: config.github.branch
  };

  if (sha) {
    body.sha = sha;
  }

  const response = await axios.put(url, body, {
    headers: {
      Authorization: `Bearer ${config.github.token}`,
      Accept: "application/vnd.github+json"
    }
  });

  logger.info(`GitHub push completed: ${path}`);

  return response.data;
}