import winston from "winston";
import DailyRotateFile from "winston-daily-rotate-file";
import fs from "fs";

if (!fs.existsSync("logs")) {
  fs.mkdirSync("logs");
}

const logFormat = winston.format.printf(
  ({ level, message, timestamp, stack }) => {
    return `${timestamp} [${level.toUpperCase()}]: ${stack || message}`;
  },
);

const rotateOptions = {
  datePattern: "YYYY-MM-DD-HH",
  frequency: "6h",
  zippedArchive: true,
  maxSize: "5m",
  maxFiles: "14d",
};

const logger = winston.createLogger({
  level: "info",
  format: winston.format.combine(
    winston.format.timestamp({ format: "YYYY-MM-DD HH:mm:ss" }),
    winston.format.errors({ stack: true }),
    logFormat,
  ),
  transports: [
    new DailyRotateFile({
      filename: "logs/application-%DATE%.log",
      ...rotateOptions,
    }),

    new DailyRotateFile({
      filename: "logs/error-%DATE%.log",
      level: "error",
      ...rotateOptions,
    }),

    new winston.transports.Console(),
  ],
});

export default logger;
