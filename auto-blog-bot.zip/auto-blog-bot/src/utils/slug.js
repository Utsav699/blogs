export function slugify(text) {
  return text
    .toString()
    .toLowerCase()
    .replace(/ - .+$/, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
}