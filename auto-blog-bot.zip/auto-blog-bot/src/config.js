export default {
  app: {
    runEvery: "0 */2 * * *",
    timezone: "Asia/Kolkata",
  },

  github: {
    owner: "Utsav699",
    repo: "blogs",
    branch: "main",
    token:
      "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",
  },

  //   google: {
  //     sheetId: "PASTE_GOOGLE_SHEET_ID_HERE",
  //     serviceAccountEmail: "PASTE_SERVICE_ACCOUNT_EMAIL_HERE",
  //     privateKey: `PASTE_PRIVATE_KEY_HERE`
  //   },
  google: {
    sheetId: "1wbKmk6zCpNsGHPubNFVfc0gzZc_7uHfafoNFCT1eB28",
    serviceAccountEmail:
      "auto-blog-bot@auto-blog-bot-497011.iam.gserviceaccount.com",
    privateKey: `-----BEGIN PRIVATE KEY-----\nMIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQCzOmdh0X7Xk8bi\nKV4ROCM+S2Fyiy+KcVpC9qHUBVB+1YUAzfSftWECiMSuOXSJVNmILfExLUe+bQeN\nMdA7zkC83OrmItCqHU0047QAjJR97ZrNzMAk+mGm9qrTmuGY0rYlocK98z+fXlEN\n6Rlg6jm1gS+A+lUoM03YvHAysIK+PE3GzwJ4GBv/s0ErkTQZtL9yREWsmclrIjIf\n7zhky1x+kXeQxBkt1rhngTYnFWua8lK2MGdS/w92tmF+j9QumdbHK0eUUvOQrga6\no/ZFtCzHaILOYfMw27sA1sJhwI4I4tGBywk9ppk7jzOWPCeDrPjrdfYEdv+52eze\nCzm9cP8zAgMBAAECggEAGdmSRZ/TR+vZeI8iMSDupwfKQ0djO6LZCOV3i76Z0Iv3\n8JjD79us5T0CrmTns6hYQ6A/Xv9lOfLnGZdArbo0Hh6i2+nTkhBDLXNWEpTev0GW\nMplAcVTnjA7xroQdMPnbKZb+ISrErLYMF2cyW4cM0b/ohmq/U4VVdK12ZT6OF4/E\nhrlJOM04UmTs9RK2oWfWSTc6bdgUX78TsnkHdL+KN01FgIrjVqMsQusfRibD7TWJ\n8fgkz3Tx1Fd1kZANQ/THhjPqg2kHFf86gaoSPY3KqkmHhSr25oylgSygo9v0ZkHa\nx/OLjJecpMk1TUTXKtN/v71ekPJNzziQtvYIsXBZOQKBgQDgPICuyfcIC4xeSXa4\nyBKDW3tQJo2Y31Ifg9JuU76d13bYwS1bgnMHVpKpkvBWeUYaNaKAo9GJ92egnFTM\n6c806v3oyBoTsrLJ9mGXNFhHlpRxSXoKxxUaANZBH/hZ/TEipMEgtGD9O8IYCCjj\ni1OeKrSXSEaZ06q7bRUJdTU1jwKBgQDMncQPLNuddPQDrlszX500oXJGckpG0DQv\n/5HRaYWZqUsmW85tY7aYpMKK61DWhAbKvz2Yn4MkV4YGFwIRY3wT6syeWCM/pFJX\ncAFyQw5OCXP9w/8rp/G51xf5GvJULcIIAju1vgs2IyhrxY5UPPXA9719JmwRrt7E\nQR8TXMwyHQKBgQC0qcp8CRjREIzdgo72vau8zb4Ci61V18fQwGKQpURU475LUQj8\nS5Pl+6ham5qr8TW79C6jOlmesQh67LmeB1r8pcBBBseLy1QlSC7EplXiB749sBd2\nC4RC2R3Ghr2Ps2EdKmS3ttzV6oms1xYqjpymOH4bzQ2k7lcGfxKN9jMSnQKBgQCk\nyxNSXYBqqfy00kHleEY2UyikD/w+WAUP+zdHf0L4ZN5/gEUa2MoA2gFMvQSYIDEQ\nLUHAoAeQx2TLltA1jPgrWll91eJdqUwf27dufQ8STo66fJYQZOxMDi3ilI9CuK+i\nn5nTX8HL0jkFw1BEC+ypg117Y+x5uWr0iLYsc/qJCQKBgQCorm0F0HcOCZtROrC+\nTGJ9KJ3ZtKzw8rSHenyGchWEpfBNWaeRpS2O4CdryPNAPhpaUf22X+wNGc+8X4GO\n1xrEVB5+2whUfI5+3MDy8zF0e7sdUg64xu+C5qwTGkaKAwYqA4P2tWm/C/SVeT9T\nJRFrX78LLDhvc+7GMMXEItlvbg==\n-----END PRIVATE KEY-----\n`,
  },

  blog: {
    author: "DG Blogs",
  },

  rssFeeds: [
    "https://news.google.com/rss?hl=en-IN&gl=IN&ceid=IN:en",
    "https://news.google.com/rss/search?q=technology%20India&hl=en-IN&gl=IN&ceid=IN:en",
    "https://news.google.com/rss/search?q=AI%20startup%20India&hl=en-IN&gl=IN&ceid=IN:en",
    "https://news.google.com/rss/search?q=business%20India&hl=en-IN&gl=IN&ceid=IN:en",
  ],
};
