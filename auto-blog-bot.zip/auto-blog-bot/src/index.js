import cron from "node-cron";
import config from "./config.js";
import logger from "./logger.js";
import { fetchTopics } from "./services/rss.service.js";
import { createBlogPost } from "./services/blog.service.js";
import { createSvgImage } from "./services/image.service.js";
import { pushFileToGitHub } from "./services/github.service.js";
import { logToSheet } from "./services/sheet.service.js";

let isRunning = false;

async function runAutomation() {
  if (isRunning) {
    logger.warn("Automation skipped because previous job is still running");
    return;
  }

  isRunning = true;
  let blog = {};

  try {
    logger.info("======================================");
    logger.info("Auto blog automation started");

    const topics = await fetchTopics(config.rssFeeds);

    blog = createBlogPost(topics[0], config.blog.author);
    logger.info(`Selected topic: ${blog.title}`);
    logger.info(`Category: ${blog.category}`);
    logger.info(`Slug: ${blog.slug}`);

    const svgImage = createSvgImage(blog);

    await pushFileToGitHub(
      blog.mdPath,
      blog.markdown,
      `Add blog post: ${blog.title}`,
    );

    await pushFileToGitHub(
      blog.imagePath,
      svgImage,
      `Add blog image: ${blog.slug}`,
    );

    await logToSheet(blog, "Published");

    logger.info(`Blog published successfully: ${blog.title}`);
    logger.info("Auto blog automation completed");
    logger.info("======================================");
  } catch (error) {
    logger.error(`Automation failed: ${error.message}`);

    try {
      await logToSheet(blog, "Failed", error.message);
    } catch (sheetError) {
      logger.error(
        `Failed to log error in Google Sheet: ${sheetError.message}`,
      );
    }
  } finally {
    isRunning = false;
  }
}

runAutomation();

cron.schedule(config.app.runEvery, runAutomation, {
  timezone: config.app.timezone,
});

logger.info("Cron scheduler started. Automation will run every 2 hours.");
