# Auto Blog Bot

Production-ready automatic blog posting system using Node.js, RSS feeds, GitHub API, Google Sheets API, SVG image generation, and rotating logs.

---

# Features

- Automatic blog posting every 2 hours
- Fetch trending topics from free RSS feeds
- Generate Markdown blog posts
- Generate free SVG blog images
- Push blog files directly to GitHub
- Save logs to Google Sheets
- Application logs + error logs
- Log rotation every 6 hours
- Rotate logs at 5MB
- Compress old logs
- No paid APIs
- No OpenAI required
- No `.env` required
- Works on localhost or VPS

---

# Technology Stack

| Technology | Purpose |
|---|---|
| Node.js | Backend runtime |
| node-cron | Scheduler |
| rss-parser | RSS topic fetching |
| axios | HTTP requests |
| googleapis | Google Sheets API |
| winston | Logging |
| winston-daily-rotate-file | Log rotation |
| GitHub REST API | File publishing |

---

# Compatible Versions

```bash
node --version
v22.12.0

npm --version
10.9.0
```

---

# Project Structure

```text
auto-blog-bot/
├── logs/
├── src/
│   ├── config.js
│   ├── index.js
│   ├── logger.js
│   ├── services/
│   │   ├── rss.service.js
│   │   ├── blog.service.js
│   │   ├── image.service.js
│   │   ├── github.service.js
│   │   └── sheet.service.js
│   └── utils/
│       └── slug.js
├── package.json
└── README.md
```

---

# Installation

## 1. Clone Repository

```bash
git clone https://github.com/UtsavBhanderi24/blogs.git
```

## 2. Create Project

```bash
mkdir auto-blog-bot
cd auto-blog-bot
```

## 3. Initialize Project

```bash
npm init -y
```

## 4. Install Dependencies

```bash
npm install axios rss-parser node-cron googleapis winston winston-daily-rotate-file
```

---

# package.json

Replace your `package.json` with:

```json
{
  "name": "auto-blog-bot",
  "version": "1.0.0",
  "description": "Auto blog posting bot using RSS, GitHub, Google Sheets and rotating logs",
  "main": "src/index.js",
  "type": "module",
  "scripts": {
    "start": "node src/index.js",
    "dev": "node src/index.js"
  },
  "engines": {
    "node": ">=22.12.0",
    "npm": ">=10.9.0"
  },
  "dependencies": {
    "axios": "^1.7.9",
    "googleapis": "^144.0.0",
    "node-cron": "^3.0.3",
    "rss-parser": "^3.13.0",
    "winston": "^3.17.0",
    "winston-daily-rotate-file": "^5.0.0"
  }
}
```

---

# Configuration

Create:

```text
src/config.js
```

```js
export default {
  app: {
    runEvery: "0 */2 * * *",
    timezone: "Asia/Kolkata"
  },

  github: {
    owner: "UtsavBhanderi24",
    repo: "blogs",
    branch: "main",
    token: "PASTE_GITHUB_TOKEN_HERE"
  },

  google: {
    sheetId: "PASTE_GOOGLE_SHEET_ID_HERE",
    serviceAccountEmail: "PASTE_SERVICE_ACCOUNT_EMAIL_HERE",
    privateKey: `PASTE_PRIVATE_KEY_HERE`
  },

  blog: {
    author: "DG Blogs"
  },

  rssFeeds: [
    "https://news.google.com/rss?hl=en-IN&gl=IN&ceid=IN:en",
    "https://news.google.com/rss/search?q=technology%20India&hl=en-IN&gl=IN&ceid=IN:en",
    "https://news.google.com/rss/search?q=AI%20startup%20India&hl=en-IN&gl=IN&ceid=IN:en",
    "https://news.google.com/rss/search?q=business%20India&hl=en-IN&gl=IN&ceid=IN:en"
  ]
};
```

---

# How It Works

```text
Every 2 Hours
→ Fetch RSS Topics
→ Select Trending Topic
→ Detect Category
→ Generate Slug
→ Generate Markdown Blog
→ Generate SVG Blog Image
→ Push Blog To GitHub
→ Push Image To GitHub
→ Save Logs To Google Sheet
→ Save Application Logs
```

---

# Generated GitHub Paths

## Markdown

```text
posts/blog-slug.md
```

## Image

```text
public/images/blog-slug.svg
```

---

# Markdown Frontmatter

Generated Markdown format:

```md
---
title: "Title"
date: "2026-05-21"
category: "Technology"
excerpt: "Short SEO description"
image: "/images/blog-image.svg"
image2: ""
author: "DG Blogs"
---
```

---

# GitHub Token Setup

## Create GitHub Token

Open:

```text
GitHub
→ Settings
→ Developer Settings
→ Personal Access Tokens
→ Fine-grained tokens
```

## Required Permission

```text
Repository Permissions:
Contents → Read and Write
```

Paste token in:

```text
src/config.js
```

---

# Google Sheets Setup

---

## 1. Create Google Sheet

Create Sheet:

```text
Blog Logs
```

Create columns:

| Column |
|---|
| DateTime |
| Status |
| Title |
| Slug |
| Category |
| MarkdownPath |
| ImagePath |
| Source |
| PostDate |
| ErrorMessage |

---

## 2. Enable APIs

Open:

```text
Google Cloud Console
```

Enable:

- Google Sheets API

---

## 3. Create Service Account

```text
Google Cloud Console
→ IAM & Admin
→ Service Accounts
→ Create Service Account
```

Download JSON key.

---

## 4. Copy Credentials

From JSON file:

```json
client_email
private_key
```

Paste into:

```text
src/config.js
```

---

## 5. Share Google Sheet

Share your Google Sheet with:

```text
service-account-email@project.iam.gserviceaccount.com
```

Permission:

```text
Editor
```

---

# Logging System

## Log Files

```text
logs/application-YYYY-MM-DD-HH.log
logs/error-YYYY-MM-DD-HH.log
```

---

## Rotation Rules

| Rule | Value |
|---|---|
| Rotation Time | Every 6 Hours |
| Max Size | 5MB |
| Compression | Enabled |
| Retention | 14 Days |

---

# Run Project

## Start Project

```bash
npm start
```

## Development Run

```bash
npm run dev
```

---

# Manual Test

Start project:

```bash
npm start
```

Immediately first execution runs automatically.

---

# Example Generated Files

## Markdown

```text
posts/india-ai-startup-growth.md
```

## SVG Image

```text
public/images/india-ai-startup-growth.svg
```

---

# Example Console Output

```bash
Auto blog automation started
Fetching RSS topics
Selected topic: India AI Startup Growth
Category: AI
Slug: india-ai-startup-growth
GitHub push completed
Google Sheet log completed
Blog published successfully
```

---

# Example Error Log

```bash
2026-05-21 10:20:15 [ERROR]: GitHub push failed
```

---

# Production Recommendations

## Best Deployment Options

| Platform | Recommended |
|---|---|
| VPS | Yes |
| Ubuntu Server | Yes |
| Windows Server | Yes |
| Docker | Optional |
| PM2 | Recommended |

---

# Run Using PM2

Install PM2:

```bash
npm install -g pm2
```

Start app:

```bash
pm2 start src/index.js --name auto-blog-bot
```

Save PM2:

```bash
pm2 save
```

Auto startup:

```bash
pm2 startup
```

---

# Security Recommendations

- Never expose GitHub token publicly
- Never commit config.js publicly
- Restrict Google service account access
- Use private repositories for automation source code

---

# Free Resources Used

| Service | Cost |
|---|---|
| RSS Feeds | Free |
| GitHub API | Free |
| SVG Images | Free |
| Google Sheets API | Free Tier |

---

# Future Improvements

- AI-generated content
- AI-generated images
- Multi-category support
- Duplicate topic detection
- SEO keyword optimization
- Auto internal linking
- Sitemap ping
- Automatic social media posting
- Multi-language blog generation

---

# Final Result

This system creates a fully automated blogging pipeline using:

- Node.js
- Free RSS feeds
- GitHub
- Google Sheets
- Automatic logging
- SVG image generation

without requiring paid APIs or manual posting.
